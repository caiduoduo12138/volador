pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
apt-get update
apt-get install net-tools
ifconfig
