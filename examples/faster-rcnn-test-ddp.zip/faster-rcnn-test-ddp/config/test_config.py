class Config:
    model_weights = " "
    image_path = " "
    gpu_id = '2'
    num_classes = 80 + 1
    data_root_dir = " "


test_cfg = Config()
