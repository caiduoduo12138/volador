"""
This example shows how to interact with the Determined PyTorch interface to
build a basic MNIST network.

In the `__init__` method, the model and optimizer are wrapped with `wrap_model`
and `wrap_optimizer`. This model is single-input and single-output.

The methods `train_batch` and `evaluate_batch` define the forward pass
for training and evaluation respectively.
"""

from typing import Any, Dict, Sequence, Tuple, Union, cast
import torch
from torch import nn
from determined.pytorch import DataLoader, PyTorchTrial, PyTorchTrialContext, LRScheduler

TorchData = Union[Dict[str, torch.Tensor], Sequence[torch.Tensor], torch.Tensor]


from config.train_config import cfg
from dataloader.coco_dataset import coco
from utils.evaluate_utils import evaluate
from utils.im_utils import Compose, ToTensor, RandomHorizontalFlip
from utils.train_utils import train_one_epoch, write_tb, create_model


class FasterRCNN(PyTorchTrial):
    def __init__(self, context: PyTorchTrialContext) -> None:
        self.context = context

        """
        get required part
        """
        data_transform = {
            "train": Compose([ToTensor(), RandomHorizontalFlip(cfg.train_horizon_flip_prob)]),
            "val": Compose([ToTensor()])
        }
        self.train_data_set = coco('/mnt/public/coco/', 'train', '2017', data_transform["train"])
        self.val_data_set = coco('/mnt/public/coco/', 'val', '2017', data_transform["val"])
        model = create_model(num_classes=cfg.num_class)
        params = [p for p in model.parameters() if p.requires_grad]
        optimizer = torch.optim.SGD(params, lr=cfg.lr, momentum=cfg.momentum, weight_decay=cfg.weight_decay)

        """
        wrap here!
        """
        self.model = self.context.wrap_model(model)  # add model here!
        self.optimizer = self.context.wrap_optimizer(optimizer)  # add optimizer here!
        lr_scheduler = torch.optim.lr_scheduler.StepLR(self.optimizer, step_size=cfg.lr_dec_step_size,
                                                       gamma=cfg.lr_gamma)  # add lr_scheduler here!
        self.lr_sch = self.context.wrap_lr_scheduler(lr_scheduler, step_mode=LRScheduler.StepMode.STEP_EVERY_EPOCH)

    def build_training_data_loader(self) -> DataLoader:
        """
        build dataloader
        """
        return DataLoader(self.train_data_set, batch_size=self.context.get_per_slot_batch_size(),
                          shuffle=True, num_workers=4, collate_fn=self.train_data_set.collate_fn)

    def build_validation_data_loader(self) -> DataLoader:
        """
        build dataloader
        """
        return DataLoader(self.val_data_set, batch_size=self.context.get_per_slot_batch_size(),
                          shuffle=False, num_workers=4, collate_fn=self.train_data_set.collate_fn)

    def train_batch(
        self, batch: TorchData, epoch_idx: int, batch_idx: int
    ) -> Dict[str, torch.Tensor]:
        batch = cast(Tuple[torch.Tensor, torch.Tensor], batch)
        images, targets = batch
        images = list(image for image in images)
        targets = [{k: v for k, v in t.items()} for t in targets]

        loss_dict = self.model(images, targets)
        losses = sum(loss for loss in loss_dict.values())

        self.context.backward(losses)
        self.context.step_optimizer(self.optimizer)

        return {"loss": losses.item()}

    def evaluate_batch(self, batch: TorchData) -> Dict[str, Any]:
        batch = cast(Tuple[torch.Tensor, torch.Tensor], batch)
        images, targets = batch
        images = list(image for image in images)
        targets = [{k: v for k, v in t.items()} for t in targets]

        self.model.train()
        val_loss_dict = self.model(images, targets)
        val_losses = sum(loss for loss in val_loss_dict.values())

        return {"validation_loss": val_losses}
