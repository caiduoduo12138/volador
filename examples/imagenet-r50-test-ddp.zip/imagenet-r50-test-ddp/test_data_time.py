import os, sys
import tqdm

import torch
import torch.nn as nn
import torchvision.transforms as transforms
import torchvision.datasets as datasets
from torch.utils.data.dataloader import DataLoader

import time
start_time = time.time()
train_dataset = datasets.ImageFolder(
    "/ssd/cai/Imagenet2012/train/",
    transforms.Compose([
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225]),
    ]))

dl = DataLoader(train_dataset, batch_size=1, shuffle=True, num_workers=4)
for each in tqdm.tqdm(dl):
    data = each[0].cuda()
    data = each[1].cuda()
end_time = time.time()
print("per_time: {}".format((end_time-start_time) / len(dl)))
print("total_time: {}".format(end_time-start_time))
