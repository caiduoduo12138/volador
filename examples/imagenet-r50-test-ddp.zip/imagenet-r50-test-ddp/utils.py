import torch
from torch.optim.optimizer import Optimizer
from math import pi, cos


def step_lr_schd(step, step_size, LR_INIT, ONE_EPOCH_STEP, WARMUP_STEPS=2000, WARMUP_FACTOR=1.0/3.0,):
    if step < WARMUP_STEPS:
        alpha = float(step) / WARMUP_STEPS
        warmup_factor = WARMUP_FACTOR * (1.0 - alpha) + alpha
        lr = LR_INIT * warmup_factor
    else:
        lr = LR_INIT * (0.1 ** (((step - WARMUP_STEPS) // ONE_EPOCH_STEP) // step_size))
    return float(lr)

def lr_schd(step, LR_INIT, TOTAL_STEP, WARMUP_STEPS=3000, target_ratio=[1, 0.01], WARMUP_FACTOR=1.0/3.0, weight=1.0):
    if step < WARMUP_STEPS:
        alpha = float(step) / WARMUP_STEPS
        warmup_factor = WARMUP_FACTOR * (1.0 - alpha) + alpha
        lr = LR_INIT * warmup_factor
    else:
        lr_start = LR_INIT * target_ratio[0]
        lr_end = LR_INIT * target_ratio[1]
        factor = (step - WARMUP_STEPS) / (TOTAL_STEP - WARMUP_STEPS - 1)
        cos_out = cos(pi * factor) + 1
        lr = lr_end + 0.5 * weight * (lr_start - lr_end) * cos_out
    return float(lr)

class SGD_GC(Optimizer):

    def __init__(self, params, lr=0.0, momentum=0, dampening=0,
                 weight_decay=0, nesterov=False):
        if lr < 0.0:
            raise ValueError("Invalid learning rate: {}".format(lr))
        if momentum < 0.0:
            raise ValueError("Invalid momentum value: {}".format(momentum))
        if weight_decay < 0.0:
            raise ValueError("Invalid weight_decay value: {}".format(weight_decay))

        defaults = dict(lr=lr, momentum=momentum, dampening=dampening,
                        weight_decay=weight_decay, nesterov=nesterov)
        if nesterov and (momentum <= 0 or dampening != 0):
            raise ValueError("Nesterov momentum requires a momentum and zero dampening")
        super(SGD_GC, self).__init__(params, defaults)

    def __setstate__(self, state):
        super(SGD_GC, self).__setstate__(state)
        for group in self.param_groups:
            group.setdefault('nesterov', False)

    def step(self, closure=None):
        """Performs a single optimization step.

        Arguments:
            closure (callable, optional): A closure that reevaluates the model
                and returns the loss.
        """
        loss = None
        if closure is not None:
            loss = closure()

        for group in self.param_groups:
            weight_decay = group['weight_decay']
            momentum = group['momentum']
            dampening = group['dampening']
            nesterov = group['nesterov']

            for p in group['params']:
                if p.grad is None:
                    continue
                d_p = p.grad.data

                if weight_decay != 0:
                    d_p.add_(weight_decay, p.data)

                # GC operation for Conv layers and FC layers
                if len(list(d_p.size())) > 1:
                    d_p.add_(-d_p.mean(dim=tuple(range(1, len(list(d_p.size())))), keepdim=True))

                if momentum != 0:
                    param_state = self.state[p]
                    if 'momentum_buffer' not in param_state:
                        buf = param_state['momentum_buffer'] = torch.clone(d_p).detach()
                    else:
                        buf = param_state['momentum_buffer']
                        buf.mul_(momentum).add_(1 - dampening, d_p)
                    if nesterov:
                        d_p = d_p.add(momentum, buf)
                    else:
                        d_p = buf

                p.data.add_(-group['lr'], d_p)

        return loss
