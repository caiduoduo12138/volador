from typing import Any, Dict, Sequence, Tuple, Union, cast
import os, sys

from determined.pytorch import DataLoader, PyTorchTrial, LRScheduler, PyTorchTrialContext, MetricReducer
from torch.cuda.amp import autocast, GradScaler

import torch
import torch.nn as nn
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import torchvision.models as models
from utils import lr_schd, step_lr_schd
from utils import SGD_GC

TorchData = Union[Dict[str, torch.Tensor], Sequence[torch.Tensor], torch.Tensor]


class ImagenetTrial(PyTorchTrial):
    def __init__(self, context: PyTorchTrialContext):
        self.context = context
        self.scaler = self.context.wrap_scaler(GradScaler()) #call wrap_scaler before wrap_model

        arch = self.context.get_hparam("arch")
        if self.context.get_hparam("pretrained"):
            print("=> using pre-trained model '{}'".format(arch))
            model = models.__dict__[arch](pretrained=True)
        else:
            print("=> creating model '{}'".format(arch))
            model = models.__dict__[arch]()

        self.model = self.context.wrap_model(model)

        self.data_directory = self.context.get_hparam("data_location")
        self.learning_rate = 0.1
        # self.learning_rate = 0.1 * self.context.get_global_batch_size() / (256.0 * self.context.get_hparam("gpu_nums"))

        optimizer = torch.optim.SGD(self.model.parameters(),
                                    self.learning_rate,
                                    momentum=self.context.get_hparam("momentum"),
                                    weight_decay=self.context.get_hparam("weight_decay"))

        # optimizer = SGD_GC(self.model.parameters(),
        #                   lr=self.learning_rate,
        #                   momentum=self.context.get_hparam("momentum"),
        #                  weight_decay=self.context.get_hparam("weight_decay"))
        self.optimizer = self.context.wrap_optimizer(optimizer)

        self.criterion = nn.CrossEntropyLoss()
        # torch.cuda.manual_seed(3407)
        self.step = 0
        if 1281167 % self.context.get_global_batch_size() == 0: # 1281167 is number of the images in train_data_loader(batch_size=1).
            self.one_steps = 1281167 // self.context.get_global_batch_size()
            self.total_steps = self.one_steps * 100  # epochs -> 120
        else:
            self.one_steps = 1281167 // self.context.get_global_batch_size() + 1
            self.total_steps = self.one_steps * 100
        # self.lr_sch = self.context.wrap_lr_scheduler(torch.optim.lr_scheduler.StepLR(self.optimizer, gamma=0.1, step_size=60),
        #                                              step_mode=LRScheduler.StepMode.STEP_EVERY_EPOCH)

    def build_training_data_loader(self):
        if self.context.get_hparam("dataset") == 'imagenet':
            traindir = os.path.join(self.data_directory, 'train')
            self.normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                        std=[0.229, 0.224, 0.225])

            train_dataset = datasets.ImageFolder(
                traindir,
                transforms.Compose([
                    transforms.RandomResizedCrop(224),
                    transforms.RandomHorizontalFlip(),
                    transforms.ToTensor(),
                    self.normalize,
                ]))

            return DataLoader(
                train_dataset, 
                batch_size=self.context.get_per_slot_batch_size(), 
                shuffle=True,
                num_workers=self.context.get_hparam("workers")) #if memory is sufficient, set pin_memory=True

    def build_validation_data_loader(self):
        if self.context.get_hparam('dataset') == 'imagenet':
            valdir = os.path.join(self.data_directory, 'val')
            self.normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                        std=[0.229, 0.224, 0.225])

            val_dataset = datasets.ImageFolder(
                valdir,
                transforms.Compose([
                    transforms.Resize(256),
                    transforms.CenterCrop(224),
                    transforms.ToTensor(),
                    self.normalize,
                ]))

            return DataLoader(
                val_dataset, batch_size=self.context.get_per_slot_batch_size(), shuffle=False,
                num_workers=self.context.get_hparam("workers"))

    def train_batch(self, batch: TorchData, epoch_idx: int, batch_idx: int):
        images, target = batch
        # for param in self.optimizer.param_groups:
        #     param["lr"] = lr_schd(step=self.step, LR_INIT=self.learning_rate, TOTAL_STEP=self.total_steps)

        for param in self.optimizer.param_groups:
            param["lr"] = step_lr_schd(step=self.step, step_size=30, LR_INIT=self.learning_rate, ONE_EPOCH_STEP=self.one_steps)

        with autocast():
            output = self.model(images)
            loss = self.criterion(output, target)
        acc1, acc5 = self.accuracy(output, target, topk=(1, 5))

        self.context.backward(self.scaler.scale(loss))
        self.context.step_optimizer(self.optimizer, scaler=self.scaler)
        self.scaler.update()
        self.step += 1

        return {"loss": loss.item(), 'top1': acc1[0], 'top5': acc5[0], 'learning_rate': self.optimizer.param_groups[0]['lr']}

    def evaluate_batch(self, batch: TorchData):
        images, target = batch

        with autocast():
            correct = 0.0
            output = self.model(images)
            # loss = self.criterion(output, target)

        # measure accuracy and record loss
        acc1, acc5 = self.accuracy(output, target, topk=(1, 5))
        return {"top1": acc1[0], "top5": acc5[0]}

    def accuracy(self, output, target, topk=(1,)):
        """Computes the accuracy over the k top predictions for the specified values of k"""
        with torch.no_grad():
            maxk = max(topk)
            batch_size = target.size(0)

            _, pred = output.topk(maxk, 1, True, True) #n, 1000 -> (n, 5)
            pred = pred.t() #(5, n)
            correct = pred.eq(target.view(1, -1).expand_as(pred))

            res = []
            for k in topk:
                correct_k = correct[:k].reshape(-1).float().sum(0, keepdim=True)
                res.append(correct_k.mul_(100.0 / batch_size))
            return res
