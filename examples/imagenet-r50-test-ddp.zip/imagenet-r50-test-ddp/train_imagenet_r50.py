import torch
import torch.nn as nn
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import torchvision.models as models

arch = "resnet50"
gpu_nums = 8
batch_size = 256 * 8
lr = 0.1
epochs = 100
print_interval = 100
val_interval = 20

traindir = ""
valdir = ""
f = open("log.txt", "a+")

class AverageMeter(object):
    """Computes and stores the average and current value"""
    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def accuracy(output, target, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    maxk = max(topk)
    batch_size = target.size(0)
    _, pred = output.topk(maxk, 1, largest=True, sorted=True)
    pred = pred.t()
    correct = pred.eq(target.view(1, -1).expand_as(pred))

    res = []
    for k in topk:
        correct_k = correct[:k].view(-1).float().sum(0, keepdim=True)
        res.append(correct_k.mul_(100.0 / batch_size))
    return res

normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
train_dataset = datasets.ImageFolder(
    traindir,
    transforms.Compose([
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normalize
    ])
)

val_dataset = datasets.ImageFolder(
    valdir,
    transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        normalize
    ])
)

train_loader = torch.utils.data.DataLoader(
    train_dataset,
    batch_size=batch_size,
    shuffle=True,
    num_workers=4,
    sampler=None
)

val_loader = torch.utils.data.DataLoader(
    val_dataset,
    batch_size=batch_size,
    shuffle=False,
    num_workers=4,
)
one_epoch_steps = len(train_loader)
total_steps = one_epoch_steps * epochs

print("=> creating model '{}'".format(arch))
model = models.__dict__[arch]().cuda()
model = torch.nn.DataParallel(model, device_ids=[i for i in range(gpu_nums)])
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=1e-4)

for epoch in range(epochs):
    _lr = lr * (0.1 ** (epoch // 30))
    for param_group in optimizer.param_groups:
        param_group['lr'] = _lr
    model.train()

    for i, (input, target) in enumerate(train_loader):
        target = target.cuda()
        input = input.cuda()

        # compute output
        losses = AverageMeter()
        top1 = AverageMeter()
        top5 = AverageMeter()

        output = model(input)
        loss = criterion(output, target)
        prec1, prec5 = accuracy(output.data, target, topk=(1, 5))
        losses.update(loss.item(), input.size(0))
        top1.update(prec1[0], input.size(0))
        top5.update(prec5[0], input.size(0))

        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        if i % print_interval == 0:
            print('Epoch: [{0}][{1}/{2}]\t'
                  'Loss {loss.val:.4f} ({loss.avg:.4f})\t'
                  'Prec@1 {top1.val:.3f} ({top1.avg:.3f})\t'
                  'Prec@5 {top5.val:.3f} ({top5.avg:.3f})\t'.format(epoch, i, len(train_loader), loss=losses, top1=top1, top5=top5))

    if (epoch+1) % val_interval == 0:
        _losses = AverageMeter()
        _top1 = AverageMeter()
        _top5 = AverageMeter()

        # switch to evaluate mode
        model.eval()

        for j, (_input, _target) in enumerate(val_loader):
            _target = _target.cuda()
            _input = _input.cuda()

            with torch.no_grad():
                # compute output
                _output = model(_input)
                _loss = criterion(_output, _target)

                # measure accuracy and record loss
                _prec1, _prec5 = accuracy(_output.data, _target, topk=(1, 5))
                _losses.update(_loss.item(), _input.size(0))
                _top1.update(_prec1[0], _input.size(0))
                _top5.update(_prec5[0], _input.size(0))

        print(' * Prec@1 {top1.avg:.3f} Prec@5 {top5.avg:.3f}'.format(top1=_top1, top5=_top5))
        f.write(' * Prec@1 {top1.avg:.3f} Prec@5 {top5.avg:.3f}'.format(top1=_top1, top5=_top5))
        torch.save(model.state_dict(), 'r50.pth')
